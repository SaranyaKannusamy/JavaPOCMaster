# Transactionality in Spring Boot with Example 
Transactionality with Spring JDBC Template with an example

### Version Used
- Spring Boot with JDBC - 1.5.15.RELEASE

### Start
- `UserRunner` - Starting point for the example which controls the `UserService`