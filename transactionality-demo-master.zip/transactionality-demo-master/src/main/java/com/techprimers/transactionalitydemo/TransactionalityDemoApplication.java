package com.techprimers.transactionalitydemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransactionalityDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransactionalityDemoApplication.class, args);
	}
}
